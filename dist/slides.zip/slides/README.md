# Slides

Marp-based slide decks for Octave AI Happy Hour and internal talks. Source is `.md`; output is `.html` (local only, not committed).

## Creating a new deck

1. Create `posts/slides/<topic>.md` with this frontmatter:
   ```markdown
   ---
   marp: true
   theme: octave
   paginate: true
   html: true
   ---
   ```
2. Add slides separated by `---` on its own line.
3. Use the layout patterns in `skills/canon-slides/SKILL.md` (3-row layout, font tiers, body+footer template).
4. Render (see below).

## Editing an existing deck

Edit `posts/slides/<topic>.md` directly:
- **Drop a slide**: delete everything between two `---` separators, including one separator line.
- **Reorder slides**: move the block (content between `---` lines) to the new position.
- **Change content**: edit the HTML/markdown inside the slide block.

Re-render after any edit.

## Rendering

**One deck:**
```bash
render-slides context-management
render-slides evaluator-pattern
```

**All decks at once:**
```bash
render-slides
```

Also available as an npm script from the repo root:
```bash
npm run slides -- context-management
npm run slides
```

Output lands at `posts/slides/<topic>.html`. Open in any browser:
```bash
open posts/slides/context-management.html
```

## Theme

All decks use the Octave brand theme at `skills/canon-slides/themes/octave.css`. Layout rules and font-size tiers are documented in `skills/canon-slides/SKILL.md`.
