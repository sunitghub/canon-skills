---
marp: true
theme: octave
paginate: true
html: true
---

<style>
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card { animation: fadeUp 0.35s both; }
.c1 { animation-delay: 0.05s; }
.c2 { animation-delay: 0.22s; }
.c3 { animation-delay: 0.39s; }
.c4 { animation-delay: 0.56s; }
.c5 { animation-delay: 0.73s; }
.step { animation: fadeUp 0.3s both; }
.s1 { animation-delay: 0.05s; }
.s2 { animation-delay: 0.18s; }
.s3 { animation-delay: 0.31s; }
.s4 { animation-delay: 0.44s; }
.s5 { animation-delay: 0.57s; }
</style>

<div style="display:flex; flex-direction:column; justify-content:center; flex:1; min-height:0; gap:24px;">
<div style="display:flex; flex-direction:column; gap:16px;">
<div style="font-size:3.2em; font-weight:900; line-height:1.1; color:#FFFFFF; letter-spacing:-0.02em;">Context Hygiene</div>
<div style="width:72px; height:4px; background:linear-gradient(90deg,#00FFFF,#4FFF00); border-radius:2px;"></div>
<div style="font-size:1.15em; color:#00FFFF; font-weight:400; line-height:1.5;">The hidden tax your agent pays before writing a single line of code</div>
</div>
</div>

---

## You think you have this

<div style="display:flex; flex-direction:column; justify-content:center; align-items:center; flex:1; min-height:0; gap:28px;">
<div style="font-size:6em; font-weight:800; color:#00FFFF; letter-spacing:-3px; line-height:1;">200,000</div>
<div style="font-size:1.05em; color:#6F7480; text-align:center;">tokens. Nice big window. Feels unlimited.</div>
</div>

---

## But here's what loads before you type a word

<div style="display:flex; align-items:stretch; flex:1; min-height:0; gap:24px;">
<div style="width:260px; flex-shrink:0; display:flex; flex-direction:column; border:1px solid rgba(0,255,255,0.22); border-radius:8px; overflow:hidden; font-size:0.72em;">
<div style="display:flex; justify-content:space-between; align-items:center; padding:8px 14px; background:rgba(0,100,100,0.5); border-bottom:1px solid rgba(0,255,255,0.2);">
<span style="font-weight:700; color:#00FFFF;">System Instructions</span><span style="color:#B2B8C4;">~6k</span>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:7px 14px; background:rgba(62,64,71,0.5); border-bottom:1px solid rgba(62,64,71,0.7);">
<span style="font-family:var(--font-mono); color:#B2B8C4;">CLAUDE.md</span><span style="color:#B2B8C4;">~3k</span>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:7px 14px; background:rgba(62,64,71,0.4); border-bottom:1px solid rgba(62,64,71,0.6);">
<span style="color:#B2B8C4;">Claude Builtin Tools</span><span style="color:#B2B8C4;">~3k</span>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:7px 14px; background:rgba(62,64,71,0.35); border-bottom:1px solid rgba(62,64,71,0.5);">
<span style="color:#B2B8C4;">MCP Tools</span><span style="color:#B2B8C4;">~2k</span>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:7px 14px; background:rgba(79,255,0,0.12); border-bottom:1px solid rgba(79,255,0,0.25);">
<span style="font-family:var(--font-mono); color:#4FFF00; font-style:italic;">go build me a dope feature</span><span style="color:#B2B8C4;">&lt;1k</span>
</div>
<div style="flex:1; display:flex; flex-direction:column; justify-content:center; align-items:center; padding:14px 12px; background:rgba(0,0,0,0.25);">
<div style="font-size:2.4em; font-weight:900; color:#00FFFF; line-height:1;">~168k</div>
<div style="font-family:var(--font-mono); color:#6F7480; font-style:italic; font-size:0.9em; margin-top:5px; text-align:center;">"the smart zone"</div>
<div style="font-family:var(--font-mono); color:#6F7480; font-style:italic; font-size:0.78em; margin-top:3px; text-align:center;">shrinks every turn with history</div>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:8px 14px; background:rgba(244,102,0,0.28); border-top:1px solid rgba(244,102,0,0.4);">
<span style="color:#F46600; font-weight:600;">reserved for auto-compact</span><span style="font-weight:800; color:#F46600;">23k</span>
</div>
<div style="display:flex; justify-content:space-between; align-items:center; padding:8px 14px; background:rgba(160,50,0,0.35); border-top:1px solid rgba(244,102,0,0.3);">
<span style="color:#F46600; font-weight:600;">reserved for output</span><span style="font-weight:800; color:#F46600;">32k</span>
</div>
</div>
<div style="flex:1; display:flex; flex-direction:column; justify-content:space-between; gap:16px; padding:4px 0;">
<div>
<div style="font-size:1.15em; font-weight:800; color:#FFF500; line-height:1.25;">~7% overhead at session start</div>
<div style="font-size:0.74em; color:#6F7480; margin-top:6px; line-height:1.5;">system prompt + tools + your message — before any work history accumulates</div>
</div>
<div>
<div style="font-size:0.8em; color:#B2B8C4; line-height:1.5;">Input budget after reserving for output.</div>
<div style="font-size:0.8em; color:#B2B8C4; line-height:1.5;">Overhead eats the top — history eats the rest.</div>
</div>
<div style="display:flex; flex-direction:column; gap:8px;">
<div style="display:flex; align-items:center; gap:10px; font-size:0.74em; color:#B2B8C4;">
<div style="width:14px; height:14px; background:rgba(244,102,0,0.5); border:1px solid #F46600; border-radius:2px; flex-shrink:0;"></div>
<span><strong style="color:#F46600;">23k</strong> — reserved for auto-compact</span>
</div>
<div style="display:flex; align-items:center; gap:10px; font-size:0.74em; color:#B2B8C4;">
<div style="width:14px; height:14px; background:rgba(160,50,0,0.5); border:1px solid #F46600; border-radius:2px; flex-shrink:0;"></div>
<span><strong style="color:#F46600;">32k</strong> — reserved for output</span>
</div>
</div>
</div>
</div>

---

## One sentence, many tokens

<div style="display:flex; flex-direction:column; justify-content:center; align-items:center; flex:1; min-height:0; gap:24px;">
<div style="font-size:2.2em; font-weight:800; color:#FFFFFF; letter-spacing:-0.02em; line-height:1.1;">Unbelievable.</div>
<div style="font-size:0.86em; color:#6F7480; text-align:center;">What you type</div>

<div style="display:flex; flex-direction:column; align-items:center; gap:6px;">
  <div style="font-size:2.0em; font-weight:800; color:#00FFFF; letter-spacing:-0.01em; line-height:1.2; text-align:center; font-family:var(--font-mono); white-space:nowrap;">Un | believable | .</div>
  <div style="display:flex; gap:54px; justify-content:center; font-size:0.8em; color:#6F7480; font-family:var(--font-mono); white-space:nowrap;">
    <span>~1</span>
    <span>~1</span>
    <span>~1</span>
  </div>
</div>
<div style="font-size:0.82em; color:#B2B8C4; text-align:center; max-width:860px;">
  This is an approximation: tokenizers split text into pieces, not characters, and the exact split depends on the model and input.
</div>
</div>

---

## The Model is stateless

<div style="display:flex; flex-direction:column; gap:10px; flex:1; min-height:0; justify-content:center;">
<div style="font-size:0.8em; color:#B2B8C4; line-height:1.35; margin-bottom:4px;">No memory between turns. Every request resends the context it needs.</div>
<div class="card c1" style="display:flex; gap:14px; align-items:flex-start; padding:12px 16px; background:rgba(111,116,128,0.2); border-left:4px solid #6F7480; border-radius:0 8px 8px 0;">
<div style="font-size:1.1em; font-weight:800; color:#6F7480; min-width:18px;">1</div>
<div><div style="font-size:0.8em; font-weight:700; color:#B2B8C4;">System prompt</div><div style="font-size:0.68em; color:#6F7480; margin-top:2px;">~14k tokens — loads every turn</div></div>
</div>
<div class="card c2" style="display:flex; gap:14px; align-items:flex-start; padding:12px 16px; background:rgba(244,102,0,0.1); border-left:4px solid #F46600; border-radius:0 8px 8px 0;">
<div style="font-size:1.1em; font-weight:800; color:#F46600; min-width:18px;">2</div>
<div><div style="font-size:0.8em; font-weight:700; color:#F46600;">Conversation history</div><div style="font-size:0.68em; color:#6F7480; margin-top:2px;">grows every turn — you pay for it every time</div></div>
</div>
<div class="card c3" style="display:flex; gap:14px; align-items:flex-start; padding:12px 16px; background:rgba(79,255,0,0.08); border-left:4px solid #4FFF00; border-radius:0 8px 8px 0;">
<div style="font-size:1.1em; font-weight:800; color:#4FFF00; min-width:18px;">3</div>
<div><div style="font-size:0.8em; font-weight:700; color:#4FFF00;">Your new message</div><div style="font-size:0.68em; color:#6F7480; margin-top:2px;">the only part that changes</div></div>
</div>
<div class="card c4" style="display:flex; gap:14px; align-items:flex-start; padding:12px 16px; background:rgba(153,51,255,0.1); border-left:4px solid #9933FF; border-radius:0 8px 8px 0;">
<div style="font-size:1.1em; font-weight:800; color:#9933FF; min-width:18px;">4</div>
<div><div style="font-size:0.8em; font-weight:700; color:#9933FF;">Previous assistant responses</div><div style="font-size:0.68em; color:#6F7480; margin-top:2px;">every output you generate is re-read as input next turn</div></div>
</div>
</div>

---

## The compounding tax

<div style="display:flex; flex-direction:column; justify-content:space-between; flex:1; min-height:0; gap:10px;">
<div class="step s1" style="display:flex; align-items:center; gap:10px;">
<div style="width:52px; font-size:0.66em; color:#6F7480; text-align:right; flex-shrink:0; line-height:1.3;">Turn<br>1</div>
<div style="width:12%; height:30px; background:#00FFFF; border-radius:2px; flex-shrink:0;"></div>
<div style="font-size:0.74em; color:#B2B8C4; margin-left:6px;"><strong>1×</strong> <span style="color:#6F7480; font-style:italic;">~2k tokens — mostly system prompt</span></div>
</div>
<div class="step s2" style="display:flex; align-items:center; gap:10px;">
<div style="width:52px; font-size:0.66em; color:#6F7480; text-align:right; flex-shrink:0; line-height:1.3;">Turn<br>5</div>
<div style="width:36%; height:30px; background:#4FFF00; border-radius:2px; flex-shrink:0;"></div>
<div style="font-size:0.74em; color:#B2B8C4; margin-left:6px;"><strong>3×</strong> <span style="color:#6F7480; font-style:italic;">~8k tokens — history now dominates</span></div>
</div>
<div class="step s3" style="display:flex; align-items:center; gap:10px;">
<div style="width:52px; font-size:0.66em; color:#6F7480; text-align:right; flex-shrink:0; line-height:1.3;">Turn<br>10</div>
<div style="width:60%; height:30px; background:#FFF500; border-radius:2px; flex-shrink:0;"></div>
<div style="font-size:0.74em; color:#B2B8C4; margin-left:6px;"><strong>6×</strong> <span style="color:#6F7480; font-style:italic;">~18k tokens — re-reading prior work each call</span></div>
</div>
<div class="step s4" style="display:flex; align-items:flex-start; gap:10px;">
<div style="width:52px; font-size:0.66em; color:#6F7480; text-align:right; flex-shrink:0; line-height:1.3; padding-top:8px;">Turn<br>20</div>
<div style="width:72%; height:30px; background:#F46600; border-radius:2px; flex-shrink:0; margin-top:8px;"></div>
<div style="font-size:0.74em; color:#B2B8C4; margin-left:6px; display:flex; flex-direction:column; gap:3px;">
<div><strong>degrades</strong></div>
<div style="color:#6F7480; font-style:italic;">50k+ tokens — attention degrades, model loses track of early details</div>
<div style="color:#F46600; font-style:italic;">silent drift — reports done without checking; same context that built it now grades it</div>
<div style="color:#FF00C7; font-style:italic; margin-top:2px;"><strong style="font-style:normal;">context anxiety</strong> — agent begins wrapping up early, before the window is actually full</div>
</div>
</div>
</div>

---

## Where context bloat comes from

<div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; flex:1; min-height:0;">
<div class="card c1" style="padding:12px 14px; background:rgba(62,64,71,0.35); border-left:4px solid #F46600; border-radius:0 10px 10px 0; display:flex; flex-direction:column; gap:5px;">
<div style="display:flex; gap:10px; align-items:center;">
<div style="width:22px; height:22px; background:#F46600; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.65em; font-weight:800; color:#1A1A1F; flex-shrink:0;">1</div>
<strong style="font-size:0.82em;">Repeating things in full</strong>
</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4;">If the agent repeats long text instead of pointing to the key part, that text gets paid for again later.</div>
<div style="font-size:0.64em; color:#4FFF00; font-weight:600;">Fix: summarize and point to the key line.</div>
<div style="font-size:0.62em; color:#6F7480; font-style:italic;">e.g. pasting a 300-line file when only line 47 matters</div>
</div>
<div class="card c2" style="padding:12px 14px; background:rgba(62,64,71,0.35); border-left:4px solid #FFF500; border-radius:0 10px 10px 0; display:flex; flex-direction:column; gap:5px;">
<div style="display:flex; gap:10px; align-items:center;">
<div style="width:22px; height:22px; background:#FFF500; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.65em; font-weight:800; color:#1A1A1F; flex-shrink:0;">2</div>
<strong style="font-size:0.82em;">Unused tools</strong>
</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4;">Tools that are loaded but not used still take up space and attention.</div>
<div style="font-size:0.64em; color:#4FFF00; font-weight:600;">Fix: keep only the tools the task needs.</div>
<div style="font-size:0.62em; color:#6F7480; font-style:italic;">e.g. web search loaded during a pure refactoring task</div>
</div>
<div class="card c3" style="padding:12px 14px; background:rgba(62,64,71,0.35); border-left:4px solid #4FFF00; border-radius:0 10px 10px 0; display:flex; flex-direction:column; gap:5px;">
<div style="display:flex; gap:10px; align-items:center;">
<div style="width:22px; height:22px; background:#4FFF00; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.65em; font-weight:800; color:#1A1A1F; flex-shrink:0;">3</div>
<strong style="font-size:0.82em;">Stuff outside the repo</strong>
</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4;">Settings, memory, and imported notes can quietly add weight every session.</div>
<div style="font-size:0.64em; color:#4FFF00; font-weight:600;">Fix: check what loads automatically.</div>
<div style="font-size:0.62em; color:#6F7480; font-style:italic;">e.g. a 200-line CLAUDE.md or MCP servers unused for weeks</div>
</div>
<div class="card c4" style="padding:12px 14px; background:rgba(62,64,71,0.35); border-left:4px solid #00FFFF; border-radius:0 10px 10px 0; display:flex; flex-direction:column; gap:5px;">
<div style="display:flex; gap:10px; align-items:center;">
<div style="width:22px; height:22px; background:#00FFFF; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.65em; font-weight:800; color:#1A1A1F; flex-shrink:0;">4</div>
<strong style="font-size:0.82em;">Reading the same thing twice</strong>
</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4;">If the agent keeps going back to the same source, it burns time and context on repetition.</div>
<div style="font-size:0.64em; color:#4FFF00; font-weight:600;">Fix: reference what was already read.</div>
<div style="font-size:0.62em; color:#6F7480; font-style:italic;">e.g. re-reading README.md at the start of every sub-task</div>
</div>
</div>

---

## context-check: what we found

<div style="display:flex; flex-direction:column; flex:1; min-height:0; gap:6px;">
<div style="font-size:0.68em; font-family:var(--font-mono); color:#6F7480; padding:6px 10px; background:rgba(62,64,71,0.3); border-radius:4px; margin-bottom:4px;">dist/context-check-fixture/</div>
<div class="card c1" style="display:flex; gap:14px; align-items:baseline; padding:10px 14px; background:rgba(244,102,0,0.08); border-left:3px solid #F46600; border-radius:0 6px 6px 0;">
<span style="font-size:0.78em; font-weight:800; color:#F46600; flex-shrink:0; min-width:130px;">Broken @-import</span>
<span style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">CLAUDE.md imports <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">legacy-runbook.md</code> — file doesn't exist; loaded every turn, returns nothing</span>
</div>
<div class="card c2" style="display:flex; gap:14px; align-items:baseline; padding:10px 14px; background:rgba(255,245,0,0.06); border-left:3px solid #FFF500; border-radius:0 6px 6px 0;">
<span style="font-size:0.78em; font-weight:800; color:#FFF500; flex-shrink:0; min-width:130px;">Always-on onboarding doc</span>
<span style="font-size:0.72em; color:#B2B8C4; line-height:1.4;"><code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">setup-guide.md</code> — 31 lines of first-time setup paid every session; irrelevant after day 1</span>
</div>
<div class="card c3" style="display:flex; gap:14px; align-items:baseline; padding:10px 14px; background:rgba(111,116,128,0.12); border-left:3px solid #6F7480; border-radius:0 6px 6px 0;">
<span style="font-size:0.78em; font-weight:800; color:#B2B8C4; flex-shrink:0; min-width:130px;">Vague instructions</span>
<span style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">"write good code", "use good judgment" — model already does this; zero constraint, pure token spend</span>
</div>
<div class="card c4" style="display:flex; gap:14px; align-items:baseline; padding:10px 14px; background:rgba(79,255,0,0.07); border-left:3px solid #4FFF00; border-radius:0 6px 6px 0;">
<span style="font-size:0.78em; font-weight:800; color:#4FFF00; flex-shrink:0; min-width:130px;">Duplicate content</span>
<span style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">AGENTS.md mirrors CLAUDE.md — Code Style, Testing, Git sections identical; same rules paid twice every turn</span>
</div>
<div class="card c5" style="display:flex; gap:14px; align-items:baseline; padding:10px 14px; background:rgba(153,51,255,0.08); border-left:3px solid #9933FF; border-radius:0 6px 6px 0;">
<span style="font-size:0.78em; font-weight:800; color:#9933FF; flex-shrink:0; min-width:130px;">5 MCP servers, 4 unused</span>
<span style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">data pipeline project needs <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">postgres</code> only — <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">filesystem</code>, <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">github</code>, <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">slack</code>, <code style="background:rgba(62,64,71,0.5); padding:1px 5px; border-radius:3px;">brave-search</code> load tool schemas every turn for nothing</span>
</div>
</div>

---

## Monitor what auto-loads

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:10px; justify-content:center;">
<div class="card c1" style="display:flex; gap:14px; align-items:stretch; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #00FFFF;">
<div style="display:flex; flex-direction:column; gap:4px; flex:1;">
<div style="font-size:0.7em; text-transform:uppercase; letter-spacing:0.08em; color:#00FFFF; font-weight:600;">Connected tools</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.4;">Claude Code: MCP servers and hooks. Claude Desktop: connectors and project tools. Keep only what the work needs.</div>
</div>
</div>
<div class="card c2" style="display:flex; gap:14px; align-items:stretch; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #9933FF;">
<div style="display:flex; flex-direction:column; gap:4px; flex:1;">
<div style="font-size:0.7em; text-transform:uppercase; letter-spacing:0.08em; color:#9933FF; font-weight:600;">Memory and long chats</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.4;">Old context can quietly shape new answers. Trim stale memory, restart long chats, and keep reusable notes short.</div>
</div>
</div>
<div class="card c3" style="display:flex; gap:14px; align-items:stretch; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #FFF500;">
<div style="display:flex; flex-direction:column; gap:4px; flex:1;">
<div style="font-size:0.7em; text-transform:uppercase; letter-spacing:0.08em; color:#FFF500; font-weight:600;">Project instructions</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.4;">Claude Code has <code>CLAUDE.md</code>; Desktop has project instructions and attached docs. Keep them short and current.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(0,255,255,0.06); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4; display:flex; justify-content:space-between; align-items:flex-start; gap:16px;">
<div>The pattern is the same in both products: auto-loaded instructions, tools, and memory can grow without you noticing.</div>
<div style="font-size:0.85em; color:#6F7480; white-space:nowrap; flex-shrink:0;">Claude Code gives you more knobs; Desktop hides more of them.</div>
</div>
</div>

---

## Two responses to a filling window

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:14px;">
<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; min-height:0;">
<div class="card c1" style="display:flex; flex-direction:column; gap:10px; padding:20px 22px; background:rgba(153,51,255,0.07); border:1px solid rgba(153,51,255,0.28); border-radius:10px;">
<div style="font-size:0.65em; color:#9933FF; text-transform:uppercase; letter-spacing:0.09em; font-weight:700;">Compaction</div>
<div style="font-size:0.82em; color:#B2B8C4; line-height:1.5;">Earlier parts of the conversation are summarised in place. The same agent continues on a shortened history.</div>
<div style="display:flex; flex-direction:column; gap:6px; margin-top:4px;">
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#4FFF00; flex-shrink:0;">✓</span><span style="color:#B2B8C4;">Preserves continuity — no handoff needed</span></div>
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#F46600; flex-shrink:0;">✗</span><span style="color:#B2B8C4;">Agent retains its sense of session length — context anxiety persists</span></div>
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#F46600; flex-shrink:0;">✗</span><span style="color:#B2B8C4;">Not a clean slate — same agent, just less history</span></div>
</div>
</div>
<div class="card c2" style="display:flex; flex-direction:column; gap:10px; padding:20px 22px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.28); border-radius:10px;">
<div style="font-size:0.65em; color:#00FFFF; text-transform:uppercase; letter-spacing:0.09em; font-weight:700;">Context Reset</div>
<div style="font-size:0.82em; color:#B2B8C4; line-height:1.5;">Window is cleared entirely. A fresh agent starts with a structured handoff artifact carrying state and next steps.</div>
<div style="display:flex; flex-direction:column; gap:6px; margin-top:4px;">
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#4FFF00; flex-shrink:0;">✓</span><span style="color:#B2B8C4;">Clean slate — resolves context anxiety</span></div>
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#4FFF00; flex-shrink:0;">✓</span><span style="color:#B2B8C4;">Coherence resets — no accumulated drift</span></div>
<div style="display:flex; gap:8px; align-items:baseline; font-size:0.72em;"><span style="color:#F46600; flex-shrink:0;">✗</span><span style="color:#B2B8C4;">Handoff artifact must carry enough state for the next agent to pick up cleanly</span></div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.35); border-left:3px solid #FFF500; border-radius:0 8px 8px 0; font-size:0.78em; color:#B2B8C4;">Compaction keeps the agent alive. A reset gives the next agent a clear head. Canon uses phase boundaries as natural reset points.</div>
</div>

---

## The fix: fresh context per phase

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:12px;">
<div class="card c1" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(0,255,255,0.2);">
<div style="padding:10px 14px; background:rgba(0,255,255,0.12); font-size:0.65em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600; text-align:center;">1 · Research</div>
<div style="flex:1; padding:12px; display:flex; flex-direction:column; gap:5px;">
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">System Instructions</div>
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">Instructions + Tools</div>
<div style="background:#1d4a2a; border:1px solid #4FFF00; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#4FFF00; text-align:center;">/research_codebase</div>
<div style="background:rgba(153,51,255,0.15); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#9933FF; text-align:center;">Task() × 3</div>
<div style="background:rgba(153,51,255,0.15); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#9933FF; text-align:center;">Write()</div>
</div>
<div style="margin:0 12px 12px; padding:8px; background:rgba(244,102,0,0.15); border:1px solid #F46600; border-radius:6px; font-size:0.62em; color:#F46600; text-align:center; font-weight:600;">→ research.md · HUMAN REVIEW</div>
</div>
<div style="display:flex; align-items:center; flex-shrink:0; padding-top:40px;">
<svg width="28" height="20" viewBox="0 0 28 20"><path d="M2 10 L22 10" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M16 4 L24 10 L16 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="card c2" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(255,245,0,0.2);">
<div style="padding:10px 14px; background:rgba(255,245,0,0.1); font-size:0.65em; text-transform:uppercase; letter-spacing:0.09em; color:#FFF500; font-weight:600; text-align:center;">2 · Planning</div>
<div style="flex:1; padding:12px; display:flex; flex-direction:column; gap:5px;">
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">System Instructions</div>
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">Instructions + Tools</div>
<div style="background:#1d4a2a; border:1px solid #4FFF00; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#4FFF00; text-align:center;">/create_plan ./research.md</div>
<div style="background:rgba(0,255,255,0.08); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#00FFFF; text-align:center;">Read(research.md)</div>
<div style="background:rgba(153,51,255,0.15); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#9933FF; text-align:center;">Task() × 3 · Write()</div>
</div>
<div style="margin:0 12px 12px; padding:8px; background:rgba(244,102,0,0.15); border:1px solid #F46600; border-radius:6px; font-size:0.62em; color:#F46600; text-align:center; font-weight:600;">→ plan.md · HUMAN REVIEW</div>
</div>
<div style="display:flex; align-items:center; flex-shrink:0; padding-top:40px;">
<svg width="28" height="20" viewBox="0 0 28 20"><path d="M2 10 L22 10" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M16 4 L24 10 L16 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="card c3" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(244,102,0,0.2);">
<div style="padding:10px 14px; background:rgba(244,102,0,0.12); font-size:0.65em; text-transform:uppercase; letter-spacing:0.09em; color:#F46600; font-weight:600; text-align:center;">3 · Implementation</div>
<div style="flex:1; padding:12px; display:flex; flex-direction:column; gap:5px;">
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">System Instructions</div>
<div style="background:#3E4047; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#B2B8C4; text-align:center;">Instructions + Tools</div>
<div style="background:#1d4a2a; border:1px solid #4FFF00; border-radius:4px; padding:7px 10px; font-size:0.6em; color:#4FFF00; text-align:center;">/implement_plan ./plan.md</div>
<div style="background:rgba(0,255,255,0.08); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#00FFFF; text-align:center;">Read() · Edit() · Write()</div>
<div style="background:rgba(153,51,255,0.15); border-radius:4px; padding:7px 10px; font-size:0.6em; color:#9933FF; text-align:center;">MultiEdit() · Task() · …</div>
</div>
<div style="margin:0 12px 12px; padding:8px; background:rgba(79,255,0,0.1); border:1px solid #4FFF00; border-radius:6px; font-size:0.62em; color:#4FFF00; text-align:center; font-weight:600;">Ships ✓</div>
</div>
</div>
</div>

---

## Audit your load

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:10px; justify-content:center;">
<div class="card c1" style="display:flex; gap:14px; align-items:center; padding:11px 16px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.82em;">
<span style="color:#00FFFF; flex-shrink:0;">→</span><span>Claude Code: run <code>/context-check</code> to list imported files and line counts</span></div>
<div class="card c2" style="display:flex; gap:14px; align-items:center; padding:11px 16px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.82em;">
<span style="color:#00FFFF; flex-shrink:0;">→</span><span>Claude Code: size registered skills and always-loaded instructions</span></div>
<div class="card c3" style="display:flex; gap:14px; align-items:center; padding:11px 16px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.82em;">
<span style="color:#00FFFF; flex-shrink:0;">→</span><span>Claude Desktop: review project instructions, attachments, connectors, and long chats</span></div>
<div class="card c4" style="display:flex; gap:14px; align-items:center; padding:11px 16px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.82em;">
<span style="color:#FFF500; flex-shrink:0;">→</span><span>Flags files where <strong>less than half</strong> the content is usually relevant</span></div>
<div class="card c5" style="display:flex; gap:14px; align-items:center; padding:11px 16px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.82em;">
<span style="color:#FFF500; flex-shrink:0;">→</span><span>Catches <strong>cross-file redundancy</strong> — same rule in two places</span></div>
</div>
<div style="padding:10px 16px; background:rgba(0,255,255,0.06); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.82em; color:#B2B8C4;">Run periodically. In Desktop, do the same review manually.</div>
</div>

---

## Five rules for context hygiene

<div style="display:flex; flex-direction:column; gap:10px; flex:1; min-height:0;">
  <div class="card c1" style="display:flex; gap:18px; align-items:center; padding:14px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #00FFFF;">
    <div style="font-size:1.5em; color:#00FFFF; font-weight:800; min-width:28px; line-height:1; flex-shrink:0;">1</div>
    <div style="font-size:0.88em; line-height:1.45;"><strong>Keep it tight from the first turn</strong> — verbose output today is a tax on every future turn</div>
  </div>
  <div class="card c2" style="display:flex; gap:18px; align-items:center; padding:14px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #4FFF00;">
    <div style="font-size:1.5em; color:#4FFF00; font-weight:800; min-width:28px; line-height:1; flex-shrink:0;">2</div>
    <div style="font-size:0.88em; line-height:1.45;"><strong>Always-on vs on-demand</strong> — load sub-skills at the step that needs them, not at session start</div>
  </div>
  <div class="card c3" style="display:flex; gap:18px; align-items:center; padding:14px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FFF500;">
    <div style="font-size:1.5em; color:#FFF500; font-weight:800; min-width:28px; line-height:1; flex-shrink:0;">3</div>
    <div style="font-size:0.88em; line-height:1.45;"><strong>Reference, don't repeat</strong> — point to the source instead of echoing content already in context</div>
  </div>
  <div class="card c4" style="display:flex; gap:18px; align-items:center; padding:14px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #F46600;">
    <div style="font-size:1.5em; color:#F46600; font-weight:800; min-width:28px; line-height:1; flex-shrink:0;">4</div>
    <div style="font-size:0.88em; line-height:1.45;"><strong>Keep tools on demand</strong> — don't load tools or skills "just in case"</div>
  </div>
  <div class="card c5" style="display:flex; gap:18px; align-items:center; padding:14px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FF00C7;">
    <div style="font-size:1.5em; color:#FF00C7; font-weight:800; min-width:28px; line-height:1; flex-shrink:0;">5</div>
    <div style="font-size:0.88em; line-height:1.45;"><strong>Measure before optimizing</strong> — audit what is loaded before guessing what's bloated</div>
  </div>
</div>

---

## Planned Talks

<div style="display:flex; flex-direction:column; flex:1; min-height:0; gap:14px;">
<div style="display:grid; grid-template-columns:1fr 1fr; gap:18px; flex:1; min-height:0;">

<div class="card c1" style="display:flex; flex-direction:column; gap:14px; padding:22px 24px; background:linear-gradient(135deg,rgba(0,255,255,0.10),rgba(62,64,71,0.30)); border:1px solid rgba(0,255,255,0.35); border-radius:12px;">
<div style="display:flex; align-items:center; gap:10px;">
<div style="width:36px; height:36px; border-radius:50%; background:linear-gradient(135deg,#00FFFF,#4FFF00); color:#1A1A1F; display:flex; align-items:center; justify-content:center; font-size:0.8em; font-weight:900; flex-shrink:0;">01</div>
<div style="font-size:0.78em; color:#00FFFF; font-weight:900; text-transform:uppercase; letter-spacing:0.04em;">Skill Evals</div>
</div>
<div style="font-size:1.05em; font-weight:800; color:#FFFFFF; line-height:1.25;">Stop Guessing If Your Agents Work</div>
<div style="width:40px; height:2px; background:linear-gradient(90deg,#00FFFF,transparent); border-radius:2px;"></div>
<div style="display:flex; flex-direction:column; gap:8px;">
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#00FFFF; flex-shrink:0; margin-top:1px;">→</span><span>What <strong style="color:#FFFFFF;">generator-evaluator collapse</strong> looks like — and why your agent's self-review can't catch it</span>
</div>
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#4FFF00; flex-shrink:0; margin-top:1px;">→</span><span>Writing <strong style="color:#FFFFFF;">adversarial test cases</strong> that surface real failure modes</span>
</div>
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#FFF500; flex-shrink:0; margin-top:1px;">→</span><span>A repeatable eval loop so you know when a skill <strong style="color:#FFFFFF;">actually got better</strong></span>
</div>
</div>
<div style="margin-top:auto; padding:8px 12px; background:rgba(0,255,255,0.07); border-radius:6px; font-size:0.64em; color:#8B9099; font-style:italic;">canon · skill-eval · evals.json</div>
</div>

<div class="card c2" style="display:flex; flex-direction:column; gap:14px; padding:22px 24px; background:linear-gradient(135deg,rgba(244,102,0,0.10),rgba(62,64,71,0.30)); border:1px solid rgba(244,102,0,0.38); border-radius:12px;">
<div style="display:flex; align-items:center; gap:10px;">
<div style="width:36px; height:36px; border-radius:50%; background:linear-gradient(135deg,#F46600,#FF00C7); color:#1A1A1F; display:flex; align-items:center; justify-content:center; font-size:0.8em; font-weight:900; flex-shrink:0;">02</div>
<div style="font-size:0.78em; color:#F46600; font-weight:900; text-transform:uppercase; letter-spacing:0.04em;">Agents In Production</div>
</div>
<div style="font-size:1.05em; font-weight:800; color:#FFFFFF; line-height:1.25;">Patterns That Survive Contact With Reality</div>
<div style="width:40px; height:2px; background:linear-gradient(90deg,#F46600,transparent); border-radius:2px;"></div>
<div style="display:flex; flex-direction:column; gap:8px;">
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#F46600; flex-shrink:0; margin-top:1px;">→</span><span><strong style="color:#FFFFFF;">Agent design patterns</strong> from canon — one job, compose don't inherit, fail loudly</span>
</div>
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#FF00C7; flex-shrink:0; margin-top:1px;">→</span><span><strong style="color:#FFFFFF;">Multi-agent orchestration</strong> — when to parallelize and when serial is safer</span>
</div>
<div style="display:flex; gap:10px; align-items:flex-start; font-size:0.72em; color:#CBD0D8; line-height:1.4;">
<span style="color:#FFF500; flex-shrink:0; margin-top:1px;">→</span><span>The <strong style="color:#FFFFFF;">five-stage incident protocol</strong> — surface, trace, isolate, fix, verify</span>
</div>
</div>
<div style="margin-top:auto; padding:8px 12px; background:rgba(244,102,0,0.07); border-radius:6px; font-size:0.64em; color:#8B9099; font-style:italic;">agent-playbook · production-incident-playbook</div>
</div>

</div>
</div>
