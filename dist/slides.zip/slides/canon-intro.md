---
marp: true
theme: octave
paginate: true
html: true
---

<style>
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card { animation: fadeUp 0.35s both; }
.c1 { animation-delay: 0.05s; } .c2 { animation-delay: 0.22s; }
.c3 { animation-delay: 0.39s; } .c4 { animation-delay: 0.56s; }
.c5 { animation-delay: 0.73s; }
.step { animation: fadeUp 0.3s both; }
.s1 { animation-delay: 0.05s; } .s2 { animation-delay: 0.18s; }
.s3 { animation-delay: 0.31s; } .s4 { animation-delay: 0.44s; }
.s5 { animation-delay: 0.57s; }
</style>

<div style="display:flex; flex-direction:column; justify-content:center; height:88%; gap:24px;">
<div style="display:flex; flex-direction:column; gap:16px;">
<div style="font-size:3.8em; font-weight:900; line-height:1.0; color:#FFFFFF; letter-spacing:-0.03em;">canon</div>
<div style="width:72px; height:4px; background:linear-gradient(90deg,#00FFFF,#4FFF00); border-radius:2px;"></div>
<div style="font-size:1.15em; color:#00FFFF; font-weight:400; line-height:1.5;">An agent workflow harness for Claude Code, Codex &amp; Pi</div>
<div style="font-size:0.82em; color:#6F7480; margin-top:8px;">Structure · Skills · Memory</div>
</div>
</div>

---

## Every AI coding session has this problem

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:14px; min-height:0;">
<div style="display:flex; flex-direction:column; gap:12px; flex:1; min-height:0;">
<div class="card c1" style="display:flex; gap:16px; align-items:flex-start; padding:16px 20px; background:rgba(244,102,0,0.08); border-radius:10px; border-left:4px solid #F46600; flex:1;">
<div style="font-size:1.5em; flex-shrink:0;">🤔</div>
<div style="font-size:0.82em; line-height:1.5;"><strong style="color:#F46600;">Sessions that forget.</strong> Each new conversation starts cold. Context, decisions, and reasoning evaporate between turns.</div>
</div>
<div class="card c2" style="display:flex; gap:16px; align-items:flex-start; padding:16px 20px; background:rgba(244,102,0,0.08); border-radius:10px; border-left:4px solid #FFF500; flex:1;">
<div style="font-size:1.5em; flex-shrink:0;">📋</div>
<div style="font-size:0.82em; line-height:1.5;"><strong style="color:#FFF500;">No contract.</strong> "Done" is defined after the work, not before. Agents optimise for the appearance of completion.</div>
</div>
<div class="card c3" style="display:flex; gap:16px; align-items:flex-start; padding:16px 20px; background:rgba(244,102,0,0.08); border-radius:10px; border-left:4px solid #FF00C7; flex:1;">
<div style="font-size:1.5em; flex-shrink:0;">🪄</div>
<div style="font-size:0.82em; line-height:1.5;"><strong style="color:#FF00C7;">Context bloat.</strong> Every rule you add loads every session — whether relevant or not. Token cost compounds silently.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Claude Code, Codex, and Pi are powerful. Raw. canon gives them structure without slowing them down.</div>
</div>

---

<!-- partial: worthwhile-harness.md -->
## What a worthwhile harness does

<div style="display:grid; grid-template-rows:auto 1fr auto; flex:1; min-height:0; gap:8px;">
<div style="padding:9px 18px; background:rgba(62,64,71,0.25); border-radius:8px; font-size:0.75em; color:#B2B8C4; line-height:1.45; text-align:center;">Most tools add <em>suggestions</em>. A harness earns its place only if it makes certain failures <strong style="color:#FFFFFF;">structurally&nbsp;impossible</strong> — not just unlikely.</div>
<div style="display:flex; align-items:stretch; gap:0; min-height:0;">
<div class="step s1" style="flex:1; display:flex; flex-direction:column; justify-content:center; gap:8px; padding:14px 16px; background:rgba(0,255,255,0.07); border-radius:10px; border:1px solid rgba(0,255,255,0.25);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">Mechanical gate</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF; line-height:1.3;">CLI <em>refuses</em> to close</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4; margin-top:2px;">Acceptance items unchecked? <code>summary.md</code> missing? Wrapup gates absent? Blocked — not warned.</div>
</div>
<div style="display:flex; align-items:center; padding:0 8px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#4FFF00" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s2" style="flex:1; display:flex; flex-direction:column; justify-content:center; gap:8px; padding:14px 16px; background:rgba(79,255,0,0.07); border-radius:10px; border:1px solid rgba(79,255,0,0.25);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#4FFF00; font-weight:600;">Adversarial review</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF; line-height:1.3;">Fresh agent checks code</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4; margin-top:2px;">No implementation context. Each criterion: pass/fail + <code>file:line</code> cite. A fail blocks. Self-review is not review.</div>
</div>
<div style="display:flex; align-items:center; padding:0 8px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#FFF500" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s3" style="flex:1; display:flex; flex-direction:column; justify-content:center; gap:8px; padding:14px 16px; background:rgba(255,245,0,0.06); border-radius:10px; border:1px solid rgba(255,245,0,0.25);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#FFF500; font-weight:600;">Delivery receipt</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF; line-height:1.3;">Plan-vs-actual written</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.4; margin-top:2px;">What shipped, what was waived, what was deferred. Permanent record — not a commit message.</div>
</div>
<div style="display:flex; align-items:center; padding:0 8px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#4FFF00" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s4" style="flex:0.7; display:flex; flex-direction:column; justify-content:center; align-items:center; gap:8px; padding:14px 12px; background:rgba(79,255,0,0.1); border-radius:10px; border:2px solid #4FFF00;">
<div style="font-size:1.8em; font-weight:900; color:#4FFF00; line-height:1;">✓</div>
<div style="font-size:0.72em; font-weight:700; color:#4FFF00; text-align:center; line-height:1.3;">Sprint<br>closed</div>
</div>
</div>
<div style="padding:9px 14px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.74em; color:#B2B8C4; font-style:italic;">The CLI enforces state and close gates; the agent and evaluator judge whether the work is actually good.</div>
</div>

---

## What is canon?

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:14px; min-height:0;">
<div style="padding:22px 28px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.3); border-radius:12px; text-align:center; font-size:1.0em; line-height:1.6; color:#FFFFFF;">A <strong style="color:#00FFFF;">workflow harness</strong> that makes AI coding sessions <strong style="color:#4FFF00;">structured</strong>, <strong style="color:#FFF500;">reproducible</strong>, and <strong style="color:#F46600;">auditable</strong> — without wrapping Claude in a framework.</div>
<div style="display:flex; gap:14px; flex:1; min-height:0;">
<div class="card c1" style="flex:1; padding:20px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-top:3px solid #00FFFF; display:flex; flex-direction:column; gap:8px;">
<div style="font-size:1.3em; font-weight:800; color:#00FFFF;">Sprint</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">Ticket → plan → build → verify → close. Every non-trivial change has a contract before code is written.</div>
</div>
<div class="card c2" style="flex:1; padding:20px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-top:3px solid #4FFF00; display:flex; flex-direction:column; gap:8px;">
<div style="font-size:1.3em; font-weight:800; color:#4FFF00;">Skills</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">On-demand context injection. Each skill is one job. Loaded only when invoked — never always-on by default.</div>
</div>
<div class="card c3" style="flex:1; padding:20px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-top:3px solid #FFF500; display:flex; flex-direction:column; gap:8px;">
<div style="font-size:1.3em; font-weight:800; color:#FFF500;">Memory</div>
<div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">Persistent cross-session facts. Decisions, discoveries, and preferences survive context compression.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #4FFF00; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Not a framework. Not an abstraction layer. Just files, git, and the right discipline injected at the right time.</div>
</div>

---

## The sprint loop

<div style="display:flex; flex-direction:column; flex:1; min-height:0; gap:14px;">
<div style="display:flex; align-items:stretch; gap:0; flex:1; min-height:0;">
<div class="step s1" style="flex:1; display:flex; flex-direction:column; align-items:center; gap:10px; padding:18px 14px; background:rgba(0,255,255,0.07); border-radius:10px 0 0 10px; border:1px solid rgba(0,255,255,0.2);">
<div style="font-size:1.8em; font-weight:900; color:#00FFFF;">1</div>
<div style="font-size:0.82em; font-weight:700; color:#00FFFF;">Ticket</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4; text-align:center;"><code>tkt create</code><br>Name the work. Open the ticket.</div>
</div>
<div style="width:2px; background:rgba(62,64,71,0.6);"></div>
<div class="step s2" style="flex:1; display:flex; flex-direction:column; align-items:center; gap:10px; padding:18px 14px; background:rgba(79,255,0,0.06); border:1px solid rgba(79,255,0,0.2); border-left:none; border-right:none;">
<div style="font-size:1.8em; font-weight:900; color:#4FFF00;">2</div>
<div style="font-size:0.82em; font-weight:700; color:#4FFF00;">Plan</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4; text-align:center;"><code>sprint start</code><br>Write acceptance criteria before touching code.</div>
</div>
<div style="width:2px; background:rgba(62,64,71,0.6);"></div>
<div class="step s3" style="flex:1; display:flex; flex-direction:column; align-items:center; gap:10px; padding:18px 14px; background:rgba(255,245,0,0.06); border:1px solid rgba(255,245,0,0.2); border-left:none; border-right:none;">
<div style="font-size:1.8em; font-weight:900; color:#FFF500;">3</div>
<div style="font-size:0.82em; font-weight:700; color:#FFF500;">Build</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4; text-align:center;">Implement. Review. Eval. Subagents own fresh-context tasks.</div>
</div>
<div style="width:2px; background:rgba(62,64,71,0.6);"></div>
<div class="step s4" style="flex:1; display:flex; flex-direction:column; align-items:center; gap:10px; padding:18px 14px; background:rgba(244,102,0,0.08); border-radius:0 10px 10px 0; border:1px solid rgba(244,102,0,0.2);">
<div style="font-size:1.8em; font-weight:900; color:#F46600;">4</div>
<div style="font-size:0.82em; font-weight:700; color:#F46600;">Close</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4; text-align:center;"><code>sprint complete</code><br>Gates verify evidence. No checkbox theatre.</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Trivial changes skip the loop. Everything else goes through it — the harness picks the lightest tier that still protects the work.</div>
</div>

---

## The validation contract

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:20px; min-height:0;">
<div style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(0,255,255,0.25);">
<div style="padding:12px 18px; background:rgba(0,255,255,0.15); font-size:0.68em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">acceptance.md — written before code</div>
<div style="flex:1; padding:16px; background:rgba(62,64,71,0.25); font-size:0.74em; line-height:1.7; color:#B2B8C4;">
<code style="color:#4FFF00;">## Criteria</code><br>
<code>- [ ] Skill asks before writing to context-findings.md</code><br>
<code>- [ ] Missing global files reported, not silently skipped</code><br>
<code>- [ ] Evidence: file name + line count per finding</code><br>
<br>
<code style="color:#4FFF00;">## Test Plan</code><br>
<code>- [ ] ./tools/canon-dev.sh lint</code><br>
<code>- [ ] skill-eval passes ≥5/7 cases</code>
</div>
</div>
<div style="flex:1; display:flex; flex-direction:column; gap:14px;">
<div class="card c1" style="flex:1; padding:16px 18px; background:rgba(79,255,0,0.06); border-radius:10px; border-left:4px solid #4FFF00; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.82em; font-weight:700; color:#4FFF00;">Written first</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;">The contract defines "done" before any code is written. Agent optimises toward the spec, not toward appearing done.</div>
</div>
<div class="card c2" style="flex:1; padding:16px 18px; background:rgba(0,255,255,0.06); border-radius:10px; border-left:4px solid #00FFFF; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.82em; font-weight:700; color:#00FFFF;">Machine-checked at close</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;"><code>sprint complete</code> validates every criterion is checked with evidence. Unchecked items block close.</div>
</div>
<div class="card c3" style="flex:1; padding:16px 18px; background:rgba(255,245,0,0.06); border-radius:10px; border-left:4px solid #FFF500; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.82em; font-weight:700; color:#FFF500;">Ticket ID in every commit</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;"><code>Closes: t-xxxx</code> in the commit body. Archaeology trace back to full reasoning and decisions, not just the diff.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #FFF500; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">The ticket is the richer record — plan.md, decisions, constraints. The commit message is the summary. Both are reachable.</div>
</div>

---

## Wrapup gates

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:8px; min-height:0;">
<div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; flex:1; min-height:0;">
<div class="card c1" style="padding:14px 18px; background:rgba(0,255,255,0.07); border-radius:10px; border-left:4px solid #00FFFF; display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">simplifier</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF;">Code quality check</div>
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.45;">Fresh subagent reviews for dead code, unnecessary complexity, scope creep. Skippable if no logic changed.</div>
</div>
<div class="card c2" style="padding:14px 18px; background:rgba(79,255,0,0.07); border-radius:10px; border-left:4px solid #4FFF00; display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#4FFF00; font-weight:600;">reviewer</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF;">Independent code review</div>
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.45;">Adversarial close review against acceptance criteria. Fresh context — no implementation bias. Skippable for trivial changes.</div>
</div>
<div class="card c3" style="padding:14px 18px; background:rgba(255,245,0,0.07); border-radius:10px; border-left:4px solid #FFF500; display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#FFF500; font-weight:600;">security</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF;">Security surface scan</div>
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.45;">Checks for OWASP top 10, exposed secrets, unsafe inputs. Skippable when no security surface is touched.</div>
</div>
<div class="card c4" style="padding:14px 18px; background:rgba(244,102,0,0.07); border-radius:10px; border-left:4px solid #F46600; display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#F46600; font-weight:600;">eval</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF;">Skill eval run</div>
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.45;">Runs <code>/skill-eval</code> against <code>evals.json</code>. Required when the sprint touches a skill. Score line must meet threshold in <code>acceptance.md</code>.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Each gate is <strong style="color:#FFFFFF;">skippable with a reason</strong> — but the reason is recorded in <code>summary.md</code>. Skipping without documenting blocks close.</div>
</div>

---

## Multi-agent dispatch

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; align-items:stretch; gap:0; min-height:0;">
<div class="step s1" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(244,102,0,0.3);">
<div style="padding:12px 10px; background:rgba(244,102,0,0.15); text-align:center;">
<span style="font-size:0.76em; font-weight:800; color:#F46600; font-family:monospace; background:rgba(244,102,0,0.2); padding:3px 10px; border-radius:4px;">explore</span>
</div>
<div style="flex:1; padding:14px 12px; background:rgba(62,64,71,0.2); display:flex; flex-direction:column; gap:10px;">
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.5;">Read and map a subsystem <em>before</em> implementation decisions.</div>
<div style="padding:8px 10px; background:rgba(244,102,0,0.08); border-radius:6px; font-size:0.66em; color:#F46600; line-height:1.4;">Protects main context from large exploratory reads</div>
</div>
<div style="padding:8px 10px; background:rgba(62,64,71,0.3); font-size:0.62em; color:#6F7480; text-align:center; letter-spacing:0.06em; text-transform:uppercase;">before build</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="18" height="18" viewBox="0 0 18 18"><path d="M3 9 L13 9 M9 5 L13 9 L9 13" stroke="#6F7480" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s2" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(0,255,255,0.25);">
<div style="padding:12px 10px; background:rgba(0,255,255,0.12); text-align:center;">
<span style="font-size:0.76em; font-weight:800; color:#00FFFF; font-family:monospace; background:rgba(0,255,255,0.15); padding:3px 10px; border-radius:4px;">implement</span>
</div>
<div style="flex:1; padding:14px 12px; background:rgba(62,64,71,0.2); display:flex; flex-direction:column; gap:10px;">
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.5;">Build or modify the approved scope.</div>
<div style="padding:8px 10px; background:rgba(0,255,255,0.07); border-radius:6px; font-size:0.66em; color:#00FFFF; line-height:1.4;">Fresh context — no baggage from planning</div>
</div>
<div style="padding:8px 10px; background:rgba(62,64,71,0.3); font-size:0.62em; color:#6F7480; text-align:center; letter-spacing:0.06em; text-transform:uppercase;">during build</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="18" height="18" viewBox="0 0 18 18"><path d="M3 9 L13 9 M9 5 L13 9 L9 13" stroke="#6F7480" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s3" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(79,255,0,0.25);">
<div style="padding:12px 10px; background:rgba(79,255,0,0.1); text-align:center;">
<span style="font-size:0.76em; font-weight:800; color:#4FFF00; font-family:monospace; background:rgba(79,255,0,0.15); padding:3px 10px; border-radius:4px;">review</span>
</div>
<div style="flex:1; padding:14px 12px; background:rgba(62,64,71,0.2); display:flex; flex-direction:column; gap:10px;">
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.5;">Independently evaluate completed work.</div>
<div style="padding:8px 10px; background:rgba(79,255,0,0.07); border-radius:6px; font-size:0.66em; color:#4FFF00; line-height:1.4;">Never seen the code — no sunk-cost bias</div>
</div>
<div style="padding:8px 10px; background:rgba(62,64,71,0.3); font-size:0.62em; color:#6F7480; text-align:center; letter-spacing:0.06em; text-transform:uppercase;">after build</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="18" height="18" viewBox="0 0 18 18"><path d="M3 9 L13 9 M9 5 L13 9 L9 13" stroke="#6F7480" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s4" style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(255,245,0,0.25);">
<div style="padding:12px 10px; background:rgba(255,245,0,0.1); text-align:center;">
<span style="font-size:0.76em; font-weight:800; color:#FFF500; font-family:monospace; background:rgba(255,245,0,0.15); padding:3px 10px; border-radius:4px;">eval</span>
</div>
<div style="flex:1; padding:14px 12px; background:rgba(62,64,71,0.2); display:flex; flex-direction:column; gap:10px;">
<div style="font-size:0.70em; color:#B2B8C4; line-height:1.5;">Adversarial close review. Executor + grader.</div>
<div style="padding:8px 10px; background:rgba(255,245,0,0.07); border-radius:6px; font-size:0.66em; color:#FFF500; line-height:1.4;">Two subagents — each with clean context</div>
</div>
<div style="padding:8px 10px; background:rgba(62,64,71,0.3); font-size:0.62em; color:#6F7480; text-align:center; letter-spacing:0.06em; text-transform:uppercase;">at close</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Every dispatch has a purpose tag. No ambiguous "do this" delegations — the tag tells the subagent its role before it reads a single line of code.</div>
</div>

---

## The evaluator pattern

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:10px; min-height:0;">
<div style="display:flex; align-items:stretch; gap:0; flex:1; min-height:0;">
<div class="step s1" style="flex:1.2; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:14px 12px; background:rgba(62,64,71,0.3); border-radius:10px; border:1px solid rgba(62,64,71,0.6);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#6F7480; font-weight:600;">input</div>
<div style="font-size:0.78em; font-weight:700; color:#FFFFFF; text-align:center; line-height:1.4;">SKILL.md<br>+ eval case</div>
<div style="font-size:0.64em; color:#6F7480; text-align:center; line-height:1.4; margin-top:2px;">scenario prompt<br>+ expectations</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s2" style="flex:1.6; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:14px 12px; background:rgba(79,255,0,0.07); border-radius:10px; border:2px solid rgba(79,255,0,0.35);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#4FFF00; font-weight:600;">new agent · fresh context</div>
<div style="font-size:0.78em; font-weight:700; color:#4FFF00; text-align:center; line-height:1.4;">Runs the scenario</div>
<div style="font-size:0.64em; color:#B2B8C4; text-align:center; line-height:1.4; margin-top:2px;">Fresh context — only SKILL.md.<br>No repo, no prior session.</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s3" style="flex:1.6; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:14px 12px; background:rgba(0,255,255,0.07); border-radius:10px; border:2px solid rgba(0,255,255,0.35);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">new agent · fresh context</div>
<div style="font-size:0.78em; font-weight:700; color:#00FFFF; text-align:center; line-height:1.4;">Grades the output</div>
<div style="font-size:0.64em; color:#B2B8C4; text-align:center; line-height:1.4; margin-top:2px;">Sees executor output only.<br>Never saw the implementation.</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s4" style="flex:1.4; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:14px 12px; background:rgba(62,64,71,0.3); border-radius:10px; border:1px solid rgba(62,64,71,0.6);">
<div style="font-size:0.62em; text-transform:uppercase; letter-spacing:0.09em; color:#6F7480; font-weight:600;">verdict</div>
<div style="display:flex; gap:8px; align-items:center; margin-top:2px;">
<span style="font-size:0.72em; font-weight:700; color:#4FFF00; background:rgba(79,255,0,0.1); padding:3px 8px; border-radius:4px;">pass</span>
<span style="font-size:0.72em; font-weight:700; color:#F46600; background:rgba(244,102,0,0.1); padding:3px 8px; border-radius:4px;">fail</span>
</div>
<div style="font-size:0.64em; color:#6F7480; text-align:center; line-height:1.4; margin-top:2px;">per expectation<br>with evidence</div>
</div>
</div>
<div style="padding:11px 16px; background:rgba(255,245,0,0.05); border-radius:8px; border:1px solid rgba(255,245,0,0.2);">
<div style="font-size:0.68em; color:#FFF500; font-weight:600; margin-bottom:4px;">e.g. context-check skill-eval — 7 cases × 2 subagents = 14 runs</div>
<div style="font-size:0.68em; color:#B2B8C4; line-height:1.5;">Graders found: case 1 proxy note missing from output → <code style="color:#00FFFF;">t-3d24</code> &nbsp;·&nbsp; case 5 fabricated findings against out-of-scope files → <code style="color:#00FFFF;">t-b45d</code>. Neither issue was caught by the author's own review.</div>
</div>
</div>
<div style="padding:9px 14px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.76em; color:#B2B8C4;">The evaluator's job is to fail — not to confirm work is done. Clean context is what makes that possible.</div>
</div>

---

## Skills — on-demand context

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:10px; min-height:0;">
<div style="display:flex; align-items:stretch; gap:0; min-height:0;">
<div class="step s1" style="flex:1.2; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; padding:12px 10px; background:rgba(62,64,71,0.3); border-radius:10px; border:1px solid rgba(62,64,71,0.6);">
<div style="font-size:0.60em; text-transform:uppercase; letter-spacing:0.09em; color:#6F7480; font-weight:600;">user types</div>
<div style="font-size:0.88em; font-weight:800; color:#4FFF00; font-family:monospace;">/context-check</div>
<div style="font-size:0.62em; color:#6F7480; text-align:center; line-height:1.3; margin-top:2px;">idle sessions pay<br>zero cost</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s2" style="flex:1.4; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; padding:12px 10px; background:rgba(79,255,0,0.07); border-radius:10px; border:2px solid rgba(79,255,0,0.3);">
<div style="font-size:0.60em; text-transform:uppercase; letter-spacing:0.09em; color:#4FFF00; font-weight:600;">injected</div>
<div style="font-size:0.76em; font-weight:700; color:#FFFFFF; text-align:center; line-height:1.3;">SKILL.md<br>into context</div>
<div style="font-size:0.62em; color:#B2B8C4; text-align:center; line-height:1.3; margin-top:2px;">frontmatter + steps<br>+ gotchas</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s3" style="flex:1.4; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; padding:12px 10px; background:rgba(0,255,255,0.07); border-radius:10px; border:2px solid rgba(0,255,255,0.3);">
<div style="font-size:0.60em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">executes</div>
<div style="font-size:0.76em; font-weight:700; color:#FFFFFF; text-align:center; line-height:1.3;">Agent follows<br>steps 1–10</div>
<div style="font-size:0.62em; color:#B2B8C4; text-align:center; line-height:1.3; margin-top:2px;">reads files, audits,<br>flags issues</div>
</div>
<div style="display:flex; align-items:center; padding:0 6px; flex-shrink:0;">
<svg width="22" height="22" viewBox="0 0 22 22"><path d="M3 11 L17 11 M12 6 L17 11 L12 16" stroke="#6F7480" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="step s4" style="flex:1.4; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; padding:12px 10px; background:rgba(255,245,0,0.06); border-radius:10px; border:2px solid rgba(255,245,0,0.3);">
<div style="font-size:0.60em; text-transform:uppercase; letter-spacing:0.09em; color:#FFF500; font-weight:600;">output</div>
<div style="font-size:0.76em; font-weight:700; color:#FFFFFF; text-align:center; line-height:1.3;">Global + Project<br>size tables</div>
<div style="font-size:0.62em; color:#B2B8C4; text-align:center; line-height:1.3; margin-top:2px;">findings + confirm<br>before writing</div>
</div>
</div>
<div style="display:flex; gap:10px; flex:1; min-height:0;">
<div style="flex:1; padding:12px 16px; background:rgba(62,64,71,0.25); border-radius:8px; border:1px solid rgba(62,64,71,0.5); display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.68em; text-transform:uppercase; letter-spacing:0.08em; color:#6F7480; font-weight:600;">one skill, one job</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">A skill that does two things is two skills. Compose them — don't combine them.</div>
</div>
<div style="flex:1; padding:12px 16px; background:rgba(62,64,71,0.25); border-radius:8px; border:1px solid rgba(62,64,71,0.5); display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.68em; text-transform:uppercase; letter-spacing:0.08em; color:#6F7480; font-weight:600;">evals built in</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">Every skill ships with <code>evals/evals.json</code>. Run <code>/skill-eval</code> to grade it.</div>
</div>
<div style="flex:1; padding:12px 16px; background:rgba(62,64,71,0.25); border-radius:8px; border:1px solid rgba(62,64,71,0.5); display:flex; flex-direction:column; gap:6px;">
<div style="font-size:0.68em; text-transform:uppercase; letter-spacing:0.08em; color:#6F7480; font-weight:600;">portable</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">Markdown files. No runtime. Works in Claude Code, Codex, and Pi.</div>
</div>
</div>
</div>
<div style="padding:9px 14px; background:rgba(62,64,71,0.3); border-left:3px solid #4FFF00; border-radius:0 8px 8px 0; font-size:0.76em; color:#B2B8C4;">98%+ of token spend is re-reading conversation history. Skills load only when called — idle sessions pay zero.</div>
</div>

---

## Skills management

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:18px; min-height:0;">
<div style="flex:1; display:flex; flex-direction:column; gap:10px; min-height:0;">
<div style="font-size:0.76em; color:#6F7480; text-transform:uppercase; letter-spacing:0.08em; font-weight:600; margin-bottom:2px;">Manage skills in your project</div>
<div class="card c1" style="display:flex; gap:12px; align-items:center; padding:9px 14px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #00FFFF;">
<code style="color:#00FFFF; font-size:0.76em; white-space:nowrap; flex-shrink:0;">skills.sh add &lt;path&gt;</code>
<div style="font-size:0.70em; color:#B2B8C4;">Register — symlinks into <code>~/.canon/skills/</code> and injects into AGENTS.md</div>
</div>
<div class="card c2" style="display:flex; gap:12px; align-items:center; padding:9px 14px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #4FFF00;">
<code style="color:#4FFF00; font-size:0.76em; white-space:nowrap; flex-shrink:0;">skills.sh remove &lt;name&gt;</code>
<div style="font-size:0.70em; color:#B2B8C4;">Unregister — removes symlink and cleans AGENTS.md entry</div>
</div>
<div class="card c3" style="display:flex; gap:12px; align-items:center; padding:9px 14px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #FFF500;">
<code style="color:#FFF500; font-size:0.76em; white-space:nowrap; flex-shrink:0;">skills.sh list</code>
<div style="font-size:0.70em; color:#B2B8C4;">Show all registered skills, category, and source path</div>
</div>
<div class="card c4" style="display:flex; gap:12px; align-items:center; padding:9px 14px; background:rgba(62,64,71,0.35); border-radius:8px; border-left:3px solid #F46600;">
<code style="color:#F46600; font-size:0.76em; white-space:nowrap; flex-shrink:0;">skills.sh status</code>
<div style="font-size:0.70em; color:#B2B8C4;">Show skills with line counts — useful for context budget audits</div>
</div>
</div>
<div style="flex:1; display:flex; flex-direction:column; gap:10px; min-height:0;">
<div style="font-size:0.76em; color:#6F7480; text-transform:uppercase; letter-spacing:0.08em; font-weight:600; margin-bottom:2px;">Share and distribute</div>
<div style="flex:1; padding:16px 18px; background:rgba(0,255,255,0.06); border-radius:10px; border:1px solid rgba(0,255,255,0.2); display:flex; flex-direction:column; gap:12px;">
<div style="font-size:0.78em; line-height:1.55; color:#B2B8C4;"><strong style="color:#00FFFF;">canon-skills repo</strong> — public install target. Skills published there are installable in any Claude Code project via <code>skills.sh add</code>.</div>
<div style="font-size:0.78em; line-height:1.55; color:#B2B8C4;"><strong style="color:#4FFF00;">Zip packaging</strong> — a skill is just a directory. Zip it, share it, drop it anywhere. Recipient runs <code>skills.sh add</code> on the unzipped path.</div>
<div style="font-size:0.78em; line-height:1.55; color:#B2B8C4;"><strong style="color:#FFF500;">No runtime dependency</strong> — skills are markdown. They work in Claude Code, Codex, and Pi without installing canon itself.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #4FFF00; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Skills are the shareable unit. Write one for any repeatable workflow — share it without sharing your whole repo setup.</div>
</div>

---

## Memory — what persists

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:16px; min-height:0;">
<div style="display:flex; flex-direction:column; gap:10px; flex:1; min-height:0;">
<div class="card c1" style="flex:1; display:flex; gap:16px; align-items:flex-start; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #00FFFF;">
<div style="font-size:1.4em; flex-shrink:0;">🧠</div>
<div>
<div style="font-size:0.82em; font-weight:700; color:#00FFFF; margin-bottom:4px;">Auto memory</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;">User profile, feedback corrections, project context, external references. Typed, indexed, reachable across sessions.</div>
</div>
</div>
<div class="card c2" style="flex:1; display:flex; gap:16px; align-items:flex-start; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #4FFF00;">
<div style="font-size:1.4em; flex-shrink:0;">📝</div>
<div>
<div style="font-size:0.82em; font-weight:700; color:#4FFF00; margin-bottom:4px;">HANDOFF.md</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;">Current focus, in-progress state, discoveries, next steps. Written at wrapup — loaded at session start. Context compression safe.</div>
</div>
</div>
<div class="card c3" style="flex:1; display:flex; gap:16px; align-items:flex-start; padding:14px 18px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FFF500;">
<div style="font-size:1.4em; flex-shrink:0;">⚖️</div>
<div>
<div style="font-size:0.82em; font-weight:700; color:#FFF500; margin-bottom:4px;">DECISIONS.md</div>
<div style="font-size:0.74em; color:#B2B8C4; line-height:1.45;">Durable choices future sprints must respect. Not a session log — non-obvious tradeoffs only, with reasoning.</div>
</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Memory is the answer to "why did we do it this way?" — findable without reading git blame across 40 commits.</div>
</div>

---

## The board

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; gap:18px; min-height:0;">
<div style="flex:1.4; display:flex; align-items:stretch; min-height:0; overflow:hidden; border-radius:10px; border:1px solid rgba(62,64,71,0.5);">
<img src="board-screenshot.png" style="width:100%; height:100%; object-fit:cover; object-position:top left; display:block;" />
</div>
<div style="flex:1; display:flex; flex-direction:column; gap:10px; min-height:0;">
<div class="card c1" style="flex:1; padding:14px 16px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #00FFFF; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.80em; font-weight:700; color:#00FFFF;">Runs locally</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;"><code>sprint-check</code> serves the board on <code>127.0.0.1:8423</code>. No cloud dependency, no auth.</div>
</div>
<div class="card c2" style="flex:1; padding:14px 16px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #4FFF00; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.80em; font-weight:700; color:#4FFF00;">Git-backed</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">Tickets are files in <code>.tickets/</code>. The board is a view — the source of truth is always git.</div>
</div>
<div class="card c3" style="flex:1; padding:14px 16px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FFF500; display:flex; flex-direction:column; justify-content:center; gap:6px;">
<div style="font-size:0.80em; font-weight:700; color:#FFF500;">Archive-aware</div>
<div style="font-size:0.72em; color:#B2B8C4; line-height:1.4;">Closed tickets stay in history. Done column doesn't grow unbounded — archivable without losing the record.</div>
</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #FFF500; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;"><em>Demo: live board with active tickets ↗</em></div>
</div>

---

## Why canon works

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:10px;">
<div style="display:flex; flex-direction:column; gap:10px; min-height:0;">
<div class="card c1" style="display:flex; gap:18px; align-items:center; padding:13px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #00FFFF; flex:1;">
<div style="font-size:1.4em; font-weight:800; color:#00FFFF; min-width:28px; text-align:center; flex-shrink:0;">1</div>
<div style="font-size:0.80em; line-height:1.45;"><strong>Accountability without overhead.</strong> Sprint workflow enforces contracts and gates — trivial changes skip it entirely. Discipline where it matters.</div>
</div>
<div class="card c2" style="display:flex; gap:18px; align-items:center; padding:13px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #4FFF00; flex:1;">
<div style="font-size:1.4em; font-weight:800; color:#4FFF00; min-width:28px; text-align:center; flex-shrink:0;">2</div>
<div style="font-size:0.80em; line-height:1.45;"><strong>Context is a budget, not a dump.</strong> Always-on vs on-demand separation keeps token spend lean. Audit it any time with <code>/context-check</code>.</div>
</div>
<div class="card c3" style="display:flex; gap:18px; align-items:center; padding:13px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FFF500; flex:1;">
<div style="font-size:1.4em; font-weight:800; color:#FFF500; min-width:28px; text-align:center; flex-shrink:0;">3</div>
<div style="font-size:0.80em; line-height:1.45;"><strong>Fresh evaluators, not self-graders.</strong> Executor + grader separation is structural. Sunk-cost bias is designed out, not coached out.</div>
</div>
<div class="card c4" style="display:flex; gap:18px; align-items:center; padding:13px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #F46600; flex:1;">
<div style="font-size:1.4em; font-weight:800; color:#F46600; min-width:28px; text-align:center; flex-shrink:0;">4</div>
<div style="font-size:0.80em; line-height:1.45;"><strong>Skills are the shareable unit.</strong> Write once, share via zip or canon-skills. No framework to install — just markdown files.</div>
</div>
<div class="card c5" style="display:flex; gap:18px; align-items:center; padding:13px 20px; background:rgba(62,64,71,0.35); border-radius:10px; border-left:4px solid #FF00C7; flex:1;">
<div style="font-size:1.4em; font-weight:800; color:#FF00C7; min-width:28px; text-align:center; flex-shrink:0;">5</div>
<div style="font-size:0.80em; line-height:1.45;"><strong>Sessions that remember.</strong> Memory, HANDOFF.md, and DECISIONS.md survive context compression and session restarts.</div>
</div>
</div>
<div style="padding:10px 16px; background:rgba(62,64,71,0.3); border-left:3px solid #00FFFF; border-radius:0 8px 8px 0; font-size:0.8em; color:#B2B8C4;">Not a framework. Not a wrapper. Claude Code, Codex, and Pi stay raw — canon adds the discipline layer on top.</div>
</div>
