# Acceptance

Ticket: `t-xxki`

## Criteria

- [x] Users can add a non-empty Todo item.
- [x] Blank Todo titles are ignored.
- [x] Users can mark a Todo complete and back open.
- [x] Todo behavior is covered by tests.

## Test Plan

- [x] `npm test`
