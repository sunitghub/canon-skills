# Blueprint

Ticket: `t-xxki`

## Goal
A dependency-free browser Todo app that supports adding and completing tasks,
used as canon's reference implementation for the walkthrough.

## Approach
- Pure functions in `src/app.js` (`createTodo`, `addTodo`, `toggleTodo`,
  `remainingCount`) so behavior is unit-testable without a DOM.
- `src/index.html` + `src/styles.css` render the list and wire input events.
- Keep Todo state in browser memory — no persistence, no framework.
- Cover add, blank-title, and toggle behavior with `node --test`.

## Out of Scope
- Persistence (localStorage/backend), editing titles, deletion, due dates.

## Open Questions
- None.
