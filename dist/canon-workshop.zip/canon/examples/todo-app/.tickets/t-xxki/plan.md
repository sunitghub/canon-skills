# Plan

Ticket: `t-xxki`

## Sprint Brief
Build a small dependency-free browser Todo app with add, complete/open, Node
tests, and npm scripts for testing and serving locally.

Approved:

- Completed Todos can be toggled back open.
- Keep the example framework-free.
