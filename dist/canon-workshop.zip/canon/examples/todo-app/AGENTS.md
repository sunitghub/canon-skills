@/Users/sunitjoshi/Developer/canon/standards/efficiency.md

<!-- AI-SKILLS:BEGIN -->
## Active canon skills
> Managed by `skills.sh` — use `add`/`remove` to change. Source: /Users/sunitjoshi/Developer/canon

| Skill | Category | Source |
|-------|----------|--------|
| sprint | dev | /Users/sunitjoshi/Developer/canon/skills/sprint.md |
<!-- AI-SKILLS:END -->
@/Users/sunitjoshi/Developer/canon/skills/sprint.md
